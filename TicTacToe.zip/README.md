# TicTacToe

## Installation

First of all this service is depend on nodejs.
For working with this bot you need to install nodejs.

Install package:

```
npm i
```

## Deploy

For running:

```
npm run dev
```
