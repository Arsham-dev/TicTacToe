import './App.css'
import Page from './page'

const App = () => {
  return (
    <div className="App">
      <Page />
    </div>
  )
}

export default App
